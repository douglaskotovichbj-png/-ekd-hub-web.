export type ClientType = 'minorista' | 'mayorista';

export const products = [
  { id: 'P001', name: 'Faro LED Cree 27W 9 LEDs', category: 'Cree LED', retail: 6500, wholesale: 5400, stock: 34, image: '🔦' },
  { id: 'P002', name: 'Barra LED 6D 18W', category: 'Barras LED', retail: 7500, wholesale: 6200, stock: 21, image: '▰' },
  { id: 'P003', name: 'Foco LED H4 Cree 6000K', category: 'Lámparas', retail: 4000, wholesale: 3200, stock: 68, image: '💡' },
  { id: 'P004', name: 'Exploradora LED U7 30W', category: 'Accesorios motos', retail: 5500, wholesale: 4550, stock: 17, image: '⚙️' },
  { id: 'P005', name: 'Ojo de Águila 2.5 LED', category: 'Universal', retail: 3500, wholesale: 2800, stock: 49, image: '◎' },
  { id: 'P006', name: 'Interruptor ON/OFF Universal', category: 'Universal', retail: 1500, wholesale: 1100, stock: 92, image: '🔘' },
];

export const clients = [
  { id: 'C001', name: 'Lucas Repuestos', type: 'mayorista' as ClientType, phone: '5491170663315', debt: 6360, charged: 18200 },
  { id: 'C002', name: 'Juan Pérez', type: 'minorista' as ClientType, phone: '5491112345678', debt: 0, charged: 12900 },
  { id: 'C003', name: 'Moto Center Norte', type: 'mayorista' as ClientType, phone: '5491122233344', debt: 15200, charged: 44800 },
];

export const invoices = [
  { id: 'B-0001', date: '2026-05-01', client: 'Lucas Repuestos', amount: 6360, status: 'Debe' },
  { id: 'B-0002', date: '2026-05-06', client: 'Juan Pérez', amount: 12900, status: 'Cobrado' },
  { id: 'B-0003', date: '2026-05-11', client: 'Moto Center Norte', amount: 15200, status: 'Debe' },
];
